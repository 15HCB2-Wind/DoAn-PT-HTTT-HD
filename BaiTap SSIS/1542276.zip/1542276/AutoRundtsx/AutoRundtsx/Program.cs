﻿using Microsoft.SqlServer.Dts.Runtime;
using System;
using System.IO;
using System.Security.Permissions;
using System.Threading;

namespace AutoRundtsx
{

    public class Watcher
    {
        static string packagepath = "";
        public static void Main()
        {
            Run();



            //string cmd = "dtexec -f \"C:\\Users\\Shin'sLaptop\\Desktop\\test\\Integration Services Project test\\Integration Services Project test\\Package.dtsx\" /set \\package.variables[input_path];\"C:\\Users\\Shin'sLaptop\\Desktop\\test\\temp.txt\"";
            ////

            ////System.Diagnostics.Process.Start( ("CMD.exe", cmd)
            //System.Diagnostics.Process process = new System.Diagnostics.Process();
            //process.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            //process.StartInfo.FileName = "cmd.exe";
            //process.StartInfo.Arguments = cmd;
            //process.Start();
        }

        public static void ExecDTSXPackage(string dtsx, string file_path)
        {
            //"C:\\Users\\Shin'sLaptop\\Desktop\\test\\Integration Services Project test\\Integration Services Project test\\Package.dtsx";
            string pkgLocation = dtsx;

            Package pkg;
            Application app;
            DTSExecResult pkgResults;
            Variables vars;

            app = new Application();
            pkg = app.LoadPackage(pkgLocation, null);

            vars = pkg.Variables;
            vars["input_path"].Value = file_path;

            pkgResults = pkg.Execute(null, vars, null, null, null);

            if (pkgResults == DTSExecResult.Success)
                Console.WriteLine("Package ran successfully");
            else
                Console.WriteLine("Package failed");

        }

        [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
        public static void Run()
        {
            Console.WriteLine("Location Package .dtsx:");
            packagepath = Console.ReadLine();

            Console.WriteLine();
            Console.Write("Folder: ");
            string path = Console.ReadLine();

            // Create a new FileSystemWatcher and set its properties.
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = path;

            /* Watch for changes in LastAccess and LastWrite times, and
               the renaming of files or directories. */
            watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
               | NotifyFilters.FileName | NotifyFilters.DirectoryName;
            // Only watch text files.
            watcher.Filter = "*.txt";

            // Add event handlers.
            watcher.Changed += new FileSystemEventHandler(OnChanged);
            watcher.Created += new FileSystemEventHandler(OnChanged);
            watcher.Deleted += new FileSystemEventHandler(OnChanged);
            watcher.Renamed += new RenamedEventHandler(OnRenamed);

            // Begin watching.
            watcher.EnableRaisingEvents = true;

            // Wait for the user to quit the program.
            Console.Write("Press \'q\' to quit the sample.");
            while (Console.Read() != 'q') ;
        }

        // Define the event handlers.
        private static void OnChanged(object source, FileSystemEventArgs e)
        {
            // Specify what is done when a file is changed, created, or deleted. Thêm 1 dòng vào nó thử
            ExecDTSXPackage(packagepath,e.FullPath);
        }

        private static void OnRenamed(object source, RenamedEventArgs e)
        {
            // Specify what is done when a file is renamed.
            ExecDTSXPackage(packagepath, e.FullPath);
        }
    }
}