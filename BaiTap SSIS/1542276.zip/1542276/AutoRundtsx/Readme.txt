1.Run - AutoRundtsx
2.Insert location of .dtsx
3.Insert folder path for watching file *.txt
4.Create/Change/Rename/Delete/Copy-Paste from folder "File Constructor" to that pointer folder
