﻿using System;
using System.IO;
using System.Security.Permissions;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Runtime;

namespace AutoInput
{
    public partial class Form1 : Form
    {
        private static string urlMySolution = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDi‌​rectory, "../../../"));

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Run();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
        public static void Run()
        {
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = urlMySolution + "/AutoInput/Input";
            /* Watch for changes in LastAccess and LastWrite times, and the renaming of files or directories. */
            watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName;
            // Only watch text files.
            watcher.Filter = "*.txt";

            // Add event handlers.
            //watcher.Changed += new FileSystemEventHandler(OnChanged);
            watcher.Created += new FileSystemEventHandler(OnChanged);
            //watcher.Deleted += new FileSystemEventHandler(OnChanged);
            //watcher.Renamed += new RenamedEventHandler(OnRenamed);

            // Begin watching.
            watcher.EnableRaisingEvents = true;
        }

        // Define the event handlers.
        private static void OnChanged(object source, FileSystemEventArgs e)
        {
            // Specify what is done when a file is changed, created, or deleted.
            MessageBox.Show(e.ChangeType.ToString());
            Execute_Package(urlMySolution + "SSIS/InputSinhVien.dtsx", e.FullPath);
        }

        private static void Execute_Package(string url_dtsx, string url_input)
        {
            string pkgLocation = url_dtsx;

            Package pkg;
            Microsoft.SqlServer.Dts.Runtime.Application app;
            DTSExecResult pkgResults;
            Variables vars;

            app = new Microsoft.SqlServer.Dts.Runtime.Application();
            pkg = app.LoadPackage(pkgLocation, null);

            vars = pkg.Variables;
            vars["path_input"].Value = url_input;

            pkgResults = pkg.Execute(null, vars, null, null, null);

            if (pkgResults == DTSExecResult.Success) MessageBox.Show("Package ran successfully!");
            else MessageBox.Show("Package failed");
        }
    }
}
