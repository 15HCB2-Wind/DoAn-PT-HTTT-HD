﻿- Chạy file script database vào SQL server 2014 trở lên
- Mở project SSIS, build
- Mở project AutoInput, build
- Chép file input.txt vào thư mục Input trong project AutoInput
- Kiểm tra database