﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SSIS.App
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public FileSystemWatcher Watcher { get; private set; }
        public string BackupFolder { get; set; }
        public string PackagesFolder { get; set; }
        public string PackageImport { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            
            //settings

            Watcher = new FileSystemWatcher
            {
                IncludeSubdirectories = false,
                NotifyFilter = NotifyFilters.LastWrite,
                Filter = "*.ssis_datatxt",
                Path = Environment.CurrentDirectory,
                EnableRaisingEvents = true,
            };

            Watcher.Changed += (a, b) =>
            {
                try
                {
                    Watcher.EnableRaisingEvents = false;

                    var cFolder = Environment.CurrentDirectory;
                    var cmd = string.Format("-f \"{0}\\{1}\" /set \\package.variables[sFile];\"{2}\" /set \\package.variables[backupFolder];\"{3}", PackagesFolder, PackageImport, b.FullPath, BackupFolder);
                    
                    var proc = new Process();
                    proc.StartInfo = new ProcessStartInfo
                    {
                        FileName = "dtexec.exe",
                        Arguments = cmd,
                        WindowStyle = ProcessWindowStyle.Hidden,
                    };
                    proc.Start();
                }
                finally
                {
                    Watcher.EnableRaisingEvents = true;
                }
            };

            BackupFolder = Watcher.Path + "\\backup";
            PackagesFolder = Watcher.Path + "\\ssis_packages";
            PackageImport = "Import.dtsx";
        }
    }
}
